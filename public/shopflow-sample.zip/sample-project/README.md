# ShopFlow — E-commerce React Native App

A full-featured mobile e-commerce application built with React Native and TypeScript.

## Features

- **Authentication** — Email/password login, OAuth (Google, Apple), biometric unlock
- **Product Catalog** — Browse, search, filter, and sort products with pagination
- **Shopping Cart** — Add/remove items, quantity management, coupon codes
- **Checkout** — Multi-step checkout with address, shipping, and payment
- **Orders** — Order history, order tracking, cancellation, and returns
- **Notifications** — Push notifications for order updates, promotions
- **Analytics** — Event tracking for user behavior and conversion funnels

## Tech Stack

- React Native 0.73 (Expo managed workflow)
- TypeScript 5.3
- Redux Toolkit + RTK Query
- React Navigation v6
- Stripe React Native SDK
- Firebase (push notifications, analytics)
- AsyncStorage for persistence
- Jest + React Native Testing Library

## Architecture

```
src/
  auth/          — Authentication flow (login, register, biometrics)
  products/      — Product listing, detail, search
  cart/          — Cart state management and UI
  checkout/      — Multi-step checkout flow
  orders/        — Order history and tracking
  notifications/ — Push notification handling
  analytics/     — Event tracking wrapper
  shared/        — Shared utilities, hooks, types, components
  api/           — API client, interceptors, error handling
```

## Getting Started

```bash
npm install
npx expo start
```

## Environment Variables

Copy `.env.example` to `.env` and fill in:

```
STRIPE_PUBLISHABLE_KEY=pk_test_...
FIREBASE_API_KEY=...
API_BASE_URL=https://api.shopflow.example.com
SENTRY_DSN=...
```

## Testing

```bash
npm test            # Run unit tests
npm run test:e2e    # Run Detox E2E tests
npm run test:cov    # Coverage report
```
