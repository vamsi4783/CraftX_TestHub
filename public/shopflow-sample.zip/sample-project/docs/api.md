# ShopFlow API Reference

Base URL: `https://api.shopflow.example.com`

## Authentication

All endpoints require `Authorization: Bearer <access_token>` except `/auth/*`.

### POST /auth/login
Body: `{ email, password }` → `{ user, tokens }`

### POST /auth/register  
Body: `{ email, password, name }` → `{ user, tokens }`

### POST /auth/refresh
Body: `{ refreshToken }` → `{ accessToken, refreshToken, expiresAt }`

### POST /auth/forgot-password
Body: `{ email }` → 204

## Products

### GET /products
Query: `page, pageSize, categoryId, query, minPrice, maxPrice, sortBy, inStockOnly`

### GET /products/:id
Returns full product with variants.

### GET /products/search
Query: `q, limit`

## Cart / Checkout

### POST /checkout/shipping-rates
Body: `{ address, items }` → `ShippingRate[]`

### POST /checkout/payment-intent
Body: `{ items, shippingAddress, shippingRateId, couponCode? }` → `{ clientSecret, total }`

### POST /checkout/place-order
Body: `{ clientSecret, paymentMethodId, ... }` → `Order`

## Orders

### GET /orders
Query: `page, pageSize`

### GET /orders/:id

### POST /orders/:id/cancel
Body: `{ reason }`

### POST /orders/:id/return
Body: `{ itemIds, reason, refundMethod }`
