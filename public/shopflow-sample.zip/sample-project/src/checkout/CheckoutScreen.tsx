import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView, Alert, ActivityIndicator } from 'react-native';
import { useSelector, useDispatch } from 'react-redux';
import { selectCartItems, selectTotal, clearCart } from '../cart/cartSlice';
import { validateShippingAddress, getShippingRates, createPaymentIntent, placeOrder, type ShippingAddress, type ShippingRate } from './checkoutService';
import { formatPrice } from '../products/productService';

type Step = 'address' | 'shipping' | 'payment' | 'confirmation';

export function CheckoutScreen({ navigation }: { navigation: any }) {
  const dispatch = useDispatch();
  const items    = useSelector(selectCartItems);
  const total    = useSelector(selectTotal);

  const [step, setStep]       = useState<Step>('address');
  const [loading, setLoading] = useState(false);

  const [address, setAddress] = useState<Partial<ShippingAddress>>({
    country: 'US',
  });
  const [rates, setRates]         = useState<ShippingRate[]>([]);
  const [selectedRate, setRate]   = useState<string | null>(null);
  const [clientSecret, setSecret] = useState<string | null>(null);
  const [orderId, setOrderId]     = useState<string | null>(null);

  const handleAddressNext = async () => {
    const errors = validateShippingAddress(address);
    if (errors.length > 0) {
      Alert.alert('Address errors', errors.join('\n'));
      return;
    }
    setLoading(true);
    try {
      const fetchedRates = await getShippingRates(address as ShippingAddress, items);
      setRates(fetchedRates);
      setStep('shipping');
    } catch (e: any) {
      Alert.alert('Error', e.message);
    } finally {
      setLoading(false);
    }
  };

  const handleShippingNext = async () => {
    if (!selectedRate) { Alert.alert('Select shipping', 'Please choose a shipping option'); return; }
    setLoading(true);
    try {
      const { clientSecret: cs } = await createPaymentIntent({
        items, shippingAddress: address as ShippingAddress, shippingRateId: selectedRate,
      });
      setSecret(cs);
      setStep('payment');
    } catch (e: any) {
      Alert.alert('Error', e.message);
    } finally {
      setLoading(false);
    }
  };

  const handlePlaceOrder = async () => {
    if (!clientSecret || !selectedRate) return;
    setLoading(true);
    try {
      const order = await placeOrder({
        clientSecret, paymentMethodId: 'pm_card_visa',
        shippingAddress: address as ShippingAddress,
        shippingRateId: selectedRate, items,
      });
      setOrderId(order.id);
      dispatch(clearCart());
      setStep('confirmation');
    } catch (e: any) {
      Alert.alert('Payment failed', e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.steps}>
        {(['address', 'shipping', 'payment', 'confirmation'] as Step[]).map((s, i) => (
          <View key={s} style={[styles.stepDot, step === s && styles.stepActive]}>
            <Text style={styles.stepNum}>{i + 1}</Text>
          </View>
        ))}
      </View>

      {step === 'address' && (
        <View style={styles.form}>
          <Text style={styles.sectionTitle}>Shipping Address</Text>
          {['fullName', 'line1', 'line2', 'city', 'state', 'postalCode', 'phone'].map(field => (
            <TextInput
              key={field}
              style={styles.input}
              placeholder={field}
              value={(address as any)[field] ?? ''}
              onChangeText={val => setAddress(prev => ({ ...prev, [field]: val }))}
            />
          ))}
          <TouchableOpacity style={styles.button} onPress={handleAddressNext} disabled={loading}>
            {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>Continue to Shipping</Text>}
          </TouchableOpacity>
        </View>
      )}

      {step === 'shipping' && (
        <View style={styles.form}>
          <Text style={styles.sectionTitle}>Shipping Method</Text>
          {rates.map(rate => (
            <TouchableOpacity key={rate.id} style={[styles.rateItem, selectedRate === rate.id && styles.rateSelected]}
              onPress={() => setRate(rate.id)}>
              <Text style={styles.rateName}>{rate.name}</Text>
              <Text style={styles.rateDesc}>{rate.description} · {rate.estimatedDays} days</Text>
              <Text style={styles.ratePrice}>{formatPrice(rate.price)}</Text>
            </TouchableOpacity>
          ))}
          <TouchableOpacity style={styles.button} onPress={handleShippingNext} disabled={loading}>
            {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>Continue to Payment</Text>}
          </TouchableOpacity>
        </View>
      )}

      {step === 'payment' && (
        <View style={styles.form}>
          <Text style={styles.sectionTitle}>Payment</Text>
          <Text>Total: {formatPrice(total)}</Text>
          <TouchableOpacity style={styles.button} onPress={handlePlaceOrder} disabled={loading}>
            {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>Place Order</Text>}
          </TouchableOpacity>
        </View>
      )}

      {step === 'confirmation' && (
        <View style={styles.confirmation}>
          <Text style={styles.confirmIcon}>✅</Text>
          <Text style={styles.confirmTitle}>Order Placed!</Text>
          <Text>Order #{orderId}</Text>
          <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('Orders')}>
            <Text style={styles.buttonText}>Track Order</Text>
          </TouchableOpacity>
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f9f9f9' },
  steps: { flexDirection: 'row', justifyContent: 'center', gap: 16, padding: 16 },
  stepDot: { width: 32, height: 32, borderRadius: 16, backgroundColor: '#ddd', justifyContent: 'center', alignItems: 'center' },
  stepActive: { backgroundColor: '#007AFF' },
  stepNum: { color: '#fff', fontWeight: '700' },
  form: { padding: 16 },
  sectionTitle: { fontSize: 18, fontWeight: '700', marginBottom: 12 },
  input: { borderWidth: 1, borderColor: '#ddd', borderRadius: 8, padding: 12, marginBottom: 8, backgroundColor: '#fff' },
  button: { backgroundColor: '#007AFF', borderRadius: 12, padding: 16, alignItems: 'center', marginTop: 12 },
  buttonText: { color: '#fff', fontWeight: '700' },
  rateItem: { borderWidth: 1, borderColor: '#ddd', borderRadius: 8, padding: 12, marginBottom: 8, backgroundColor: '#fff' },
  rateSelected: { borderColor: '#007AFF' },
  rateName: { fontWeight: '600' },
  rateDesc: { color: '#666', fontSize: 13 },
  ratePrice: { color: '#007AFF', fontWeight: '700', marginTop: 4 },
  confirmation: { padding: 32, alignItems: 'center' },
  confirmIcon: { fontSize: 64, marginBottom: 16 },
  confirmTitle: { fontSize: 24, fontWeight: '700', marginBottom: 8 },
});
