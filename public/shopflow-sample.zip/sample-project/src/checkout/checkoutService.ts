import axios from 'axios';
import { confirmPayment } from '@stripe/stripe-react-native';
import { API_BASE_URL } from '../api/config';
import type { CartItem } from '../cart/cartSlice';

export interface ShippingAddress {
  fullName: string;
  line1: string;
  line2?: string;
  city: string;
  state: string;
  postalCode: string;
  country: string;
  phone: string;
}

export interface ShippingRate {
  id: string;
  name: string;
  description: string;
  price: number;
  estimatedDays: number;
}

export interface Order {
  id: string;
  orderNumber: string;
  status: 'pending' | 'confirmed' | 'shipped' | 'delivered' | 'cancelled';
  items: CartItem[];
  shippingAddress: ShippingAddress;
  shippingRateId: string;
  subtotal: number;
  shippingTotal: number;
  discountAmount: number;
  total: number;
  createdAt: string;
}

export async function getShippingRates(address: ShippingAddress, items: CartItem[]): Promise<ShippingRate[]> {
  const response = await axios.post(`${API_BASE_URL}/checkout/shipping-rates`, { address, items });
  return response.data;
}

export async function createPaymentIntent(params: {
  items: CartItem[];
  shippingAddress: ShippingAddress;
  shippingRateId: string;
  couponCode?: string;
}): Promise<{ clientSecret: string; total: number }> {
  const response = await axios.post(`${API_BASE_URL}/checkout/payment-intent`, params);
  return response.data;
}

export async function placeOrder(params: {
  clientSecret: string;
  paymentMethodId: string;
  shippingAddress: ShippingAddress;
  shippingRateId: string;
  items: CartItem[];
  couponCode?: string;
}): Promise<Order> {
  // Confirm Stripe payment first
  const { error } = await confirmPayment(params.clientSecret, {
    paymentMethodType: 'Card',
  });
  if (error) throw new Error(error.message);

  const response = await axios.post(`${API_BASE_URL}/checkout/place-order`, params);
  return response.data;
}

export function validateShippingAddress(address: Partial<ShippingAddress>): string[] {
  const errors: string[] = [];
  if (!address.fullName?.trim()) errors.push('Full name is required');
  if (!address.line1?.trim()) errors.push('Address line 1 is required');
  if (!address.city?.trim()) errors.push('City is required');
  if (!address.state?.trim()) errors.push('State is required');
  if (!address.postalCode?.trim()) errors.push('Postal code is required');
  if (!address.country?.trim()) errors.push('Country is required');
  if (!address.phone?.trim()) errors.push('Phone is required');
  return errors;
}
