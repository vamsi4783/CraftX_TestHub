import { formatPrice, getDiscountPercent, searchProducts } from '../productService';

jest.mock('axios');

describe('formatPrice()', () => {
  it('converts cents to dollar string', () => {
    expect(formatPrice(1999)).toBe('$19.99');
    expect(formatPrice(100)).toBe('$1.00');
    expect(formatPrice(0)).toBe('$0.00');
  });
});

describe('getDiscountPercent()', () => {
  it('returns 0 when no compareAtPrice', () => {
    expect(getDiscountPercent(1000, 0)).toBe(0);
  });
  it('calculates correct discount', () => {
    expect(getDiscountPercent(800, 1000)).toBe(20);
  });
  it('returns 0 when compareAtPrice <= price', () => {
    expect(getDiscountPercent(1000, 900)).toBe(0);
  });
});

describe('searchProducts()', () => {
  it('returns empty array for blank query', async () => {
    const result = await searchProducts('   ');
    expect(result).toEqual([]);
  });

  it('calls API with trimmed query', async () => {
    const axios = require('axios');
    axios.get.mockResolvedValue({ data: { items: [{ id: 'p1', name: 'Widget' }] } });
    const result = await searchProducts('  widget  ');
    expect(result).toHaveLength(1);
    expect(axios.get).toHaveBeenCalledWith(expect.stringContaining('search'), expect.objectContaining({
      params: expect.objectContaining({ q: 'widget' }),
    }));
  });
});
