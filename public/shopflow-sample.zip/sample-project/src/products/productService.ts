import axios from 'axios';
import { API_BASE_URL } from '../api/config';

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;         // in cents
  compareAtPrice?: number;
  images: string[];
  categoryId: string;
  categoryName: string;
  tags: string[];
  rating: number;        // 0–5
  reviewCount: number;
  inStock: boolean;
  stockQuantity: number;
  sku: string;
  variants?: ProductVariant[];
}

export interface ProductVariant {
  id: string;
  name: string;
  price: number;
  stockQuantity: number;
  sku: string;
}

export interface ProductListParams {
  page?: number;
  pageSize?: number;
  categoryId?: string;
  query?: string;
  minPrice?: number;
  maxPrice?: number;
  sortBy?: 'price_asc' | 'price_desc' | 'rating' | 'newest';
  inStockOnly?: boolean;
}

export interface ProductListResult {
  items: Product[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
}

export async function listProducts(params: ProductListParams = {}): Promise<ProductListResult> {
  const response = await axios.get(`${API_BASE_URL}/products`, { params });
  return response.data;
}

export async function getProduct(id: string): Promise<Product> {
  if (!id) throw new Error('Product ID is required');
  const response = await axios.get(`${API_BASE_URL}/products/${id}`);
  return response.data;
}

export async function searchProducts(query: string, limit = 20): Promise<Product[]> {
  if (!query.trim()) return [];
  const response = await axios.get(`${API_BASE_URL}/products/search`, {
    params: { q: query.trim(), limit },
  });
  return response.data.items;
}

export async function getRelatedProducts(productId: string): Promise<Product[]> {
  const response = await axios.get(`${API_BASE_URL}/products/${productId}/related`);
  return response.data.items;
}

export async function getCategories(): Promise<{ id: string; name: string; slug: string }[]> {
  const response = await axios.get(`${API_BASE_URL}/categories`);
  return response.data;
}

export function formatPrice(cents: number): string {
  return `$${(cents / 100).toFixed(2)}`;
}

export function getDiscountPercent(price: number, compareAtPrice: number): number {
  if (!compareAtPrice || compareAtPrice <= price) return 0;
  return Math.round(((compareAtPrice - price) / compareAtPrice) * 100);
}
