import React, { useEffect, useState } from 'react';
import { View, Text, ScrollView, Image, TouchableOpacity, StyleSheet, ActivityIndicator, Alert } from 'react-native';
import { getProduct, formatPrice, getDiscountPercent, type Product } from './productService';
import { useDispatch } from 'react-redux';
import { addItem } from '../cart/cartSlice';

export function ProductDetailScreen({ route, navigation }: { route: any; navigation: any }) {
  const { productId } = route.params;
  const dispatch = useDispatch();

  const [product, setProduct]           = useState<Product | null>(null);
  const [loading, setLoading]           = useState(true);
  const [selectedVariant, setVariant]   = useState<string | null>(null);
  const [quantity, setQuantity]         = useState(1);

  useEffect(() => {
    getProduct(productId)
      .then(setProduct)
      .catch(() => Alert.alert('Error', 'Could not load product'))
      .finally(() => setLoading(false));
  }, [productId]);

  if (loading) return <ActivityIndicator style={{ flex: 1 }} />;
  if (!product) return <Text>Product not found</Text>;

  const variant = product.variants?.find(v => v.id === selectedVariant);
  const price   = variant?.price ?? product.price;
  const discount = product.compareAtPrice ? getDiscountPercent(price, product.compareAtPrice) : 0;

  const handleAddToCart = () => {
    if (product.variants && product.variants.length > 0 && !selectedVariant) {
      Alert.alert('Select option', 'Please choose a variant before adding to cart');
      return;
    }
    dispatch(addItem({ product, variantId: selectedVariant ?? undefined, quantity }));
    Alert.alert('Added!', `${product.name} added to your cart`);
  };

  return (
    <ScrollView style={styles.container}>
      <ScrollView horizontal pagingEnabled>
        {product.images.map((img, i) => (
          <Image key={i} source={{ uri: img }} style={styles.image} />
        ))}
      </ScrollView>

      <View style={styles.body}>
        <Text style={styles.name}>{product.name}</Text>
        <View style={styles.priceRow}>
          <Text style={styles.price}>{formatPrice(price)}</Text>
          {discount > 0 && (
            <>
              <Text style={styles.compareAt}>{formatPrice(product.compareAtPrice!)}</Text>
              <Text style={styles.badge}>{discount}% OFF</Text>
            </>
          )}
        </View>

        <Text style={styles.rating}>{'★'.repeat(Math.round(product.rating))} ({product.reviewCount})</Text>
        {!product.inStock && <Text style={styles.outOfStock}>Out of Stock</Text>}

        {product.variants && product.variants.length > 0 && (
          <View style={styles.variants}>
            <Text style={styles.sectionTitle}>Options</Text>
            <View style={styles.variantRow}>
              {product.variants.map(v => (
                <TouchableOpacity
                  key={v.id}
                  style={[styles.variantChip, selectedVariant === v.id && styles.variantSelected]}
                  onPress={() => setVariant(v.id)}
                >
                  <Text>{v.name}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        )}

        <Text style={styles.sectionTitle}>Description</Text>
        <Text style={styles.description}>{product.description}</Text>

        <TouchableOpacity
          style={[styles.addButton, (!product.inStock) && styles.addButtonDisabled]}
          onPress={handleAddToCart}
          disabled={!product.inStock}
        >
          <Text style={styles.addButtonText}>{product.inStock ? 'Add to Cart' : 'Out of Stock'}</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  image: { width: 375, height: 375 },
  body: { padding: 16 },
  name: { fontSize: 22, fontWeight: '700', marginBottom: 8 },
  priceRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 8 },
  price: { fontSize: 24, fontWeight: '700', color: '#007AFF' },
  compareAt: { fontSize: 16, textDecorationLine: 'line-through', color: '#999' },
  badge: { backgroundColor: '#FF3B30', color: '#fff', paddingHorizontal: 6, borderRadius: 4, fontSize: 12 },
  rating: { color: '#FF9500', marginBottom: 8 },
  outOfStock: { color: '#FF3B30', fontWeight: '600', marginBottom: 8 },
  variants: { marginVertical: 12 },
  variantRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  variantChip: { borderWidth: 1, borderColor: '#ddd', borderRadius: 8, padding: 8 },
  variantSelected: { borderColor: '#007AFF', backgroundColor: '#EAF2FF' },
  sectionTitle: { fontSize: 16, fontWeight: '600', marginTop: 16, marginBottom: 8 },
  description: { color: '#555', lineHeight: 22 },
  addButton: { backgroundColor: '#007AFF', borderRadius: 12, padding: 16, alignItems: 'center', marginTop: 24 },
  addButtonDisabled: { backgroundColor: '#ccc' },
  addButtonText: { color: '#fff', fontWeight: '700', fontSize: 16 },
});
