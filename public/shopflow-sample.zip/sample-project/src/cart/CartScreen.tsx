import React from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, Image } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { removeItem, updateQuantity, selectCartItems, selectSubtotal, selectTotal, selectDiscount } from './cartSlice';
import { formatPrice } from '../products/productService';

export function CartScreen({ navigation }: { navigation: any }) {
  const dispatch = useDispatch();
  const items    = useSelector(selectCartItems);
  const subtotal = useSelector(selectSubtotal);
  const discount = useSelector(selectDiscount);
  const total    = useSelector(selectTotal);

  if (items.length === 0) {
    return (
      <View style={styles.empty}>
        <Text style={styles.emptyText}>Your cart is empty</Text>
        <TouchableOpacity onPress={() => navigation.navigate('Products')}>
          <Text style={styles.link}>Start shopping</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <FlatList
        data={items}
        keyExtractor={item => `${item.productId}-${item.variantId ?? 'default'}`}
        renderItem={({ item }) => (
          <View style={styles.item}>
            {item.image && <Image source={{ uri: item.image }} style={styles.image} />}
            <View style={styles.itemInfo}>
              <Text style={styles.itemName}>{item.name}</Text>
              <Text style={styles.itemPrice}>{formatPrice(item.price)}</Text>
              <View style={styles.qtyRow}>
                <TouchableOpacity onPress={() => dispatch(updateQuantity({ productId: item.productId, variantId: item.variantId, quantity: item.quantity - 1 }))}>
                  <Text style={styles.qtyBtn}>−</Text>
                </TouchableOpacity>
                <Text style={styles.qty}>{item.quantity}</Text>
                <TouchableOpacity onPress={() => dispatch(updateQuantity({ productId: item.productId, variantId: item.variantId, quantity: item.quantity + 1 }))}>
                  <Text style={styles.qtyBtn}>+</Text>
                </TouchableOpacity>
              </View>
            </View>
            <TouchableOpacity onPress={() => dispatch(removeItem({ productId: item.productId, variantId: item.variantId }))}>
              <Text style={styles.remove}>✕</Text>
            </TouchableOpacity>
          </View>
        )}
      />
      <View style={styles.summary}>
        <View style={styles.row}><Text>Subtotal</Text><Text>{formatPrice(subtotal)}</Text></View>
        {discount > 0 && <View style={styles.row}><Text style={styles.discount}>Coupon</Text><Text style={styles.discount}>-{formatPrice(discount)}</Text></View>}
        <View style={[styles.row, styles.totalRow]}><Text style={styles.totalLabel}>Total</Text><Text style={styles.totalValue}>{formatPrice(total)}</Text></View>
        <TouchableOpacity style={styles.checkoutBtn} onPress={() => navigation.navigate('Checkout')}>
          <Text style={styles.checkoutText}>Proceed to Checkout</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  empty: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  emptyText: { fontSize: 18, color: '#999', marginBottom: 12 },
  link: { color: '#007AFF', fontSize: 16 },
  item: { flexDirection: 'row', padding: 16, borderBottomWidth: 1, borderColor: '#eee', alignItems: 'center' },
  image: { width: 60, height: 60, borderRadius: 8, marginRight: 12 },
  itemInfo: { flex: 1 },
  itemName: { fontWeight: '600', marginBottom: 4 },
  itemPrice: { color: '#007AFF', marginBottom: 8 },
  qtyRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  qtyBtn: { fontSize: 20, color: '#007AFF', paddingHorizontal: 8 },
  qty: { fontSize: 16, fontWeight: '600' },
  remove: { color: '#FF3B30', fontSize: 18, padding: 4 },
  summary: { padding: 16, borderTopWidth: 1, borderColor: '#eee', backgroundColor: '#fff' },
  row: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  discount: { color: '#34C759' },
  totalRow: { marginTop: 8, borderTopWidth: 1, borderColor: '#eee', paddingTop: 8 },
  totalLabel: { fontWeight: '700', fontSize: 16 },
  totalValue: { fontWeight: '700', fontSize: 16, color: '#007AFF' },
  checkoutBtn: { backgroundColor: '#007AFF', borderRadius: 12, padding: 16, alignItems: 'center', marginTop: 12 },
  checkoutText: { color: '#fff', fontWeight: '700', fontSize: 16 },
});
