import { createSlice, PayloadAction, createSelector } from '@reduxjs/toolkit';
import type { Product } from '../products/productService';

export interface CartItem {
  productId: string;
  variantId?: string;
  name: string;
  price: number;
  image?: string;
  quantity: number;
  sku: string;
}

interface CartState {
  items: CartItem[];
  couponCode: string | null;
  discountAmount: number;
}

const initialState: CartState = { items: [], couponCode: null, discountAmount: 0 };

export const cartSlice = createSlice({
  name: 'cart',
  initialState,
  reducers: {
    addItem(state, action: PayloadAction<{ product: Product; variantId?: string; quantity: number }>) {
      const { product, variantId, quantity } = action.payload;
      const variant = product.variants?.find(v => v.id === variantId);
      const existing = state.items.find(
        i => i.productId === product.id && i.variantId === variantId,
      );
      if (existing) {
        existing.quantity += quantity;
      } else {
        state.items.push({
          productId: product.id,
          variantId,
          name: variant ? `${product.name} — ${variant.name}` : product.name,
          price: variant?.price ?? product.price,
          image: product.images[0],
          quantity,
          sku: variant?.sku ?? product.sku,
        });
      }
    },
    removeItem(state, action: PayloadAction<{ productId: string; variantId?: string }>) {
      const { productId, variantId } = action.payload;
      state.items = state.items.filter(
        i => !(i.productId === productId && i.variantId === variantId),
      );
    },
    updateQuantity(state, action: PayloadAction<{ productId: string; variantId?: string; quantity: number }>) {
      const { productId, variantId, quantity } = action.payload;
      const item = state.items.find(i => i.productId === productId && i.variantId === variantId);
      if (item) {
        if (quantity <= 0) {
          state.items = state.items.filter(i => i !== item);
        } else {
          item.quantity = quantity;
        }
      }
    },
    applyCoupon(state, action: PayloadAction<{ code: string; discountAmount: number }>) {
      state.couponCode = action.payload.code;
      state.discountAmount = action.payload.discountAmount;
    },
    removeCoupon(state) {
      state.couponCode = null;
      state.discountAmount = 0;
    },
    clearCart(state) {
      state.items = [];
      state.couponCode = null;
      state.discountAmount = 0;
    },
  },
});

export const { addItem, removeItem, updateQuantity, applyCoupon, removeCoupon, clearCart } = cartSlice.actions;

export const selectCartItems = (state: { cart: CartState }) => state.cart.items;
export const selectItemCount = createSelector(selectCartItems, items => items.reduce((n, i) => n + i.quantity, 0));
export const selectSubtotal  = createSelector(selectCartItems, items => items.reduce((n, i) => n + i.price * i.quantity, 0));
export const selectDiscount  = (state: { cart: CartState }) => state.cart.discountAmount;
export const selectTotal     = createSelector(selectSubtotal, selectDiscount, (sub, disc) => Math.max(0, sub - disc));

export default cartSlice.reducer;
