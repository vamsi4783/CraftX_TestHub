import cartReducer, { addItem, removeItem, updateQuantity, applyCoupon, clearCart, selectItemCount, selectSubtotal, selectTotal } from '../cartSlice';

const mockProduct = {
  id: 'p1', name: 'Test Widget', description: '', price: 2000, images: [],
  categoryId: 'c1', categoryName: 'Widgets', tags: [], rating: 4, reviewCount: 10,
  inStock: true, stockQuantity: 100, sku: 'WIDGET-001',
};

describe('cartSlice reducers', () => {
  it('starts empty', () => {
    const state = cartReducer(undefined, { type: '@@init' });
    expect(state.items).toHaveLength(0);
  });

  it('adds an item', () => {
    const state = cartReducer(undefined, addItem({ product: mockProduct, quantity: 1 }));
    expect(state.items).toHaveLength(1);
    expect(state.items[0].productId).toBe('p1');
    expect(state.items[0].quantity).toBe(1);
  });

  it('increments quantity when adding the same item twice', () => {
    let state = cartReducer(undefined, addItem({ product: mockProduct, quantity: 1 }));
    state = cartReducer(state, addItem({ product: mockProduct, quantity: 2 }));
    expect(state.items).toHaveLength(1);
    expect(state.items[0].quantity).toBe(3);
  });

  it('removes an item', () => {
    let state = cartReducer(undefined, addItem({ product: mockProduct, quantity: 1 }));
    state = cartReducer(state, removeItem({ productId: 'p1' }));
    expect(state.items).toHaveLength(0);
  });

  it('updateQuantity to 0 removes the item', () => {
    let state = cartReducer(undefined, addItem({ product: mockProduct, quantity: 1 }));
    state = cartReducer(state, updateQuantity({ productId: 'p1', quantity: 0 }));
    expect(state.items).toHaveLength(0);
  });

  it('clears the cart', () => {
    let state = cartReducer(undefined, addItem({ product: mockProduct, quantity: 3 }));
    state = cartReducer(state, clearCart());
    expect(state.items).toHaveLength(0);
  });
});

describe('cart selectors', () => {
  const stateWith2Items = {
    cart: cartReducer(
      cartReducer(undefined, addItem({ product: mockProduct, quantity: 2 })),
      applyCoupon({ code: 'SAVE5', discountAmount: 500 }),
    ),
  };

  it('selectItemCount sums quantities', () => {
    expect(selectItemCount(stateWith2Items)).toBe(2);
  });

  it('selectSubtotal multiplies price × qty', () => {
    expect(selectSubtotal(stateWith2Items)).toBe(4000);
  });

  it('selectTotal subtracts discount', () => {
    expect(selectTotal(stateWith2Items)).toBe(3500);
  });
});
