import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';
import axios from 'axios';
import { API_BASE_URL } from '../api/config';

export type NotificationTopic = 'order_updates' | 'promotions' | 'restock_alerts' | 'account';

export interface AppNotification {
  id: string;
  type: NotificationTopic;
  title: string;
  body: string;
  data?: Record<string, string>;
  readAt?: string;
  createdAt: string;
}

export async function requestPushPermissions(): Promise<boolean> {
  if (Platform.OS === 'android') {
    await Notifications.setNotificationChannelAsync('default', {
      name: 'Default',
      importance: Notifications.AndroidImportance.HIGH,
    });
  }
  const { status } = await Notifications.requestPermissionsAsync();
  return status === 'granted';
}

export async function registerPushToken(userId: string): Promise<void> {
  const granted = await requestPushPermissions();
  if (!granted) return;
  const token = (await Notifications.getExpoPushTokenAsync()).data;
  await axios.post(`${API_BASE_URL}/users/${userId}/push-token`, { token, platform: Platform.OS });
}

export async function getNotifications(page = 1): Promise<{ items: AppNotification[]; unreadCount: number }> {
  const response = await axios.get(`${API_BASE_URL}/notifications`, { params: { page } });
  return response.data;
}

export async function markAsRead(notificationId: string): Promise<void> {
  await axios.patch(`${API_BASE_URL}/notifications/${notificationId}/read`);
}

export async function markAllAsRead(): Promise<void> {
  await axios.post(`${API_BASE_URL}/notifications/read-all`);
}

export async function updateNotificationPreferences(prefs: Record<NotificationTopic, boolean>): Promise<void> {
  await axios.put(`${API_BASE_URL}/users/me/notification-preferences`, prefs);
}
