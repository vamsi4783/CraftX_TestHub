import axios from 'axios';
import { API_BASE_URL } from '../api/config';
import type { Order } from '../checkout/checkoutService';

export type OrderStatus = Order['status'];

export interface OrderTrackingEvent {
  status: string;
  description: string;
  location?: string;
  timestamp: string;
}

export async function listOrders(page = 1, pageSize = 20): Promise<{ items: Order[]; total: number }> {
  const response = await axios.get(`${API_BASE_URL}/orders`, { params: { page, pageSize } });
  return response.data;
}

export async function getOrder(orderId: string): Promise<Order> {
  const response = await axios.get(`${API_BASE_URL}/orders/${orderId}`);
  return response.data;
}

export async function getOrderTracking(orderId: string): Promise<OrderTrackingEvent[]> {
  const response = await axios.get(`${API_BASE_URL}/orders/${orderId}/tracking`);
  return response.data;
}

export async function cancelOrder(orderId: string, reason: string): Promise<Order> {
  const response = await axios.post(`${API_BASE_URL}/orders/${orderId}/cancel`, { reason });
  return response.data;
}

export async function requestReturn(orderId: string, params: {
  itemIds: string[];
  reason: string;
  refundMethod: 'original' | 'store_credit';
}): Promise<{ returnId: string; label?: string }> {
  const response = await axios.post(`${API_BASE_URL}/orders/${orderId}/return`, params);
  return response.data;
}

export function getStatusLabel(status: OrderStatus): string {
  const labels: Record<OrderStatus, string> = {
    pending:   'Processing',
    confirmed: 'Confirmed',
    shipped:   'On its way',
    delivered: 'Delivered',
    cancelled: 'Cancelled',
  };
  return labels[status] ?? status;
}

export function canCancel(status: OrderStatus): boolean {
  return status === 'pending' || status === 'confirmed';
}

export function canReturn(status: OrderStatus): boolean {
  return status === 'delivered';
}
