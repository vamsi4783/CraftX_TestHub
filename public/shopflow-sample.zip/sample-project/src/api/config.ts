export const API_BASE_URL = process.env.API_BASE_URL ?? 'https://api.shopflow.example.com';
export const REQUEST_TIMEOUT_MS = 15_000;
