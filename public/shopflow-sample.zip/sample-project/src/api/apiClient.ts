import axios, { type AxiosInstance, type InternalAxiosRequestConfig } from 'axios';
import { API_BASE_URL, REQUEST_TIMEOUT_MS } from './config';
import { getStoredTokens, refreshTokens } from '../auth/authService';

let isRefreshing = false;
let refreshQueue: Array<(token: string) => void> = [];

function processRefreshQueue(token: string) {
  refreshQueue.forEach(cb => cb(token));
  refreshQueue = [];
}

export function createApiClient(): AxiosInstance {
  const client = axios.create({
    baseURL: API_BASE_URL,
    timeout: REQUEST_TIMEOUT_MS,
    headers: { 'Content-Type': 'application/json' },
  });

  client.interceptors.request.use(async (config: InternalAxiosRequestConfig) => {
    const tokens = await getStoredTokens();
    if (tokens?.accessToken) {
      config.headers.Authorization = `Bearer ${tokens.accessToken}`;
    }
    return config;
  });

  client.interceptors.response.use(
    response => response,
    async error => {
      const original = error.config;
      if (error.response?.status === 401 && !original._retry) {
        original._retry = true;
        if (isRefreshing) {
          return new Promise(resolve => {
            refreshQueue.push(token => {
              original.headers.Authorization = `Bearer ${token}`;
              resolve(client(original));
            });
          });
        }
        isRefreshing = true;
        try {
          const newTokens = await refreshTokens();
          processRefreshQueue(newTokens.accessToken);
          original.headers.Authorization = `Bearer ${newTokens.accessToken}`;
          return client(original);
        } catch {
          return Promise.reject(error);
        } finally {
          isRefreshing = false;
        }
      }
      return Promise.reject(error);
    },
  );

  return client;
}

export const apiClient = createApiClient();
