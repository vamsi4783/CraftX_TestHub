export function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
}

export function isValidPhone(phone: string): boolean {
  return /^\+?[\d\s\-()]{7,15}$/.test(phone.trim());
}

export function isValidPostalCode(code: string, country = 'US'): boolean {
  if (country === 'US') return /^\d{5}(-\d{4})?$/.test(code);
  if (country === 'CA') return /^[A-Z]\d[A-Z]\s?\d[A-Z]\d$/i.test(code);
  return code.trim().length >= 3;
}

export function sanitizeSearchQuery(query: string): string {
  return query.replace(/[<>'"]/g, '').trim().slice(0, 200);
}

export function clamp(value: number, min: number, max: number): number {
  return Math.min(Math.max(value, min), max);
}
