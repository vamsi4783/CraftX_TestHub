import { login, register, logout, requestPasswordReset } from '../authService';

jest.mock('axios');
jest.mock('@react-native-async-storage/async-storage', () => ({
  setItem: jest.fn(),
  getItem: jest.fn(),
  removeItem: jest.fn(),
  multiSet: jest.fn(),
  multiRemove: jest.fn(),
}));
jest.mock('expo-local-authentication');

describe('authService', () => {
  describe('login()', () => {
    it('throws when email is empty', async () => {
      await expect(login({ email: '', password: 'pw' })).rejects.toThrow('Email and password are required');
    });

    it('throws when password is empty', async () => {
      await expect(login({ email: 'a@b.com', password: '' })).rejects.toThrow('Email and password are required');
    });

    it('calls API and persists session on success', async () => {
      const axios = require('axios');
      axios.post.mockResolvedValue({
        data: {
          user: { id: 'u1', email: 'a@b.com', name: 'Alice', role: 'customer' },
          tokens: { accessToken: 'tok', refreshToken: 'ref', expiresAt: 9999 },
        },
      });
      const result = await login({ email: 'a@b.com', password: 'password123' });
      expect(result.user.email).toBe('a@b.com');
    });
  });

  describe('register()', () => {
    it('throws when password is shorter than 8 chars', async () => {
      await expect(register({ email: 'a@b.com', password: 'short', name: 'Alice' })).rejects.toThrow('Password must be at least 8 characters');
    });
  });

  describe('requestPasswordReset()', () => {
    it('calls forgot-password endpoint', async () => {
      const axios = require('axios');
      axios.post.mockResolvedValue({ data: {} });
      await expect(requestPasswordReset('a@b.com')).resolves.toBeUndefined();
    });
  });
});
