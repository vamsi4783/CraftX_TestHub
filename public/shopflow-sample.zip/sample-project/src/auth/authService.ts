import axios from 'axios';
import * as LocalAuthentication from 'expo-local-authentication';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { API_BASE_URL } from '../api/config';

export interface LoginCredentials {
  email: string;
  password: string;
}

export interface AuthUser {
  id: string;
  email: string;
  name: string;
  avatarUrl?: string;
  role: 'customer' | 'admin';
}

export interface AuthTokens {
  accessToken: string;
  refreshToken: string;
  expiresAt: number;
}

const TOKEN_KEY = '@shopflow:tokens';
const USER_KEY = '@shopflow:user';

export async function login(credentials: LoginCredentials): Promise<{ user: AuthUser; tokens: AuthTokens }> {
  if (!credentials.email || !credentials.password) {
    throw new Error('Email and password are required');
  }
  const response = await axios.post(`${API_BASE_URL}/auth/login`, credentials);
  const { user, tokens } = response.data;
  await persistSession(user, tokens);
  return { user, tokens };
}

export async function loginWithGoogle(idToken: string): Promise<{ user: AuthUser; tokens: AuthTokens }> {
  const response = await axios.post(`${API_BASE_URL}/auth/google`, { idToken });
  const { user, tokens } = response.data;
  await persistSession(user, tokens);
  return { user, tokens };
}

export async function loginWithApple(identityToken: string, fullName: string | null): Promise<{ user: AuthUser; tokens: AuthTokens }> {
  const response = await axios.post(`${API_BASE_URL}/auth/apple`, { identityToken, fullName });
  const { user, tokens } = response.data;
  await persistSession(user, tokens);
  return { user, tokens };
}

export async function register(params: { email: string; password: string; name: string }): Promise<{ user: AuthUser; tokens: AuthTokens }> {
  if (params.password.length < 8) {
    throw new Error('Password must be at least 8 characters');
  }
  const response = await axios.post(`${API_BASE_URL}/auth/register`, params);
  const { user, tokens } = response.data;
  await persistSession(user, tokens);
  return { user, tokens };
}

export async function logout(): Promise<void> {
  const tokens = await getStoredTokens();
  if (tokens) {
    try {
      await axios.post(`${API_BASE_URL}/auth/logout`, { refreshToken: tokens.refreshToken });
    } catch { /* fire-and-forget */ }
  }
  await AsyncStorage.multiRemove([TOKEN_KEY, USER_KEY]);
}

export async function refreshTokens(): Promise<AuthTokens> {
  const tokens = await getStoredTokens();
  if (!tokens) throw new Error('No tokens to refresh');
  const response = await axios.post(`${API_BASE_URL}/auth/refresh`, { refreshToken: tokens.refreshToken });
  const newTokens: AuthTokens = response.data;
  await AsyncStorage.setItem(TOKEN_KEY, JSON.stringify(newTokens));
  return newTokens;
}

export async function authenticateWithBiometrics(): Promise<boolean> {
  const compatible = await LocalAuthentication.hasHardwareAsync();
  if (!compatible) return false;
  const enrolled = await LocalAuthentication.isEnrolledAsync();
  if (!enrolled) return false;
  const result = await LocalAuthentication.authenticateAsync({
    promptMessage: 'Authenticate to continue',
    cancelLabel: 'Cancel',
    fallbackLabel: 'Use PIN',
  });
  return result.success;
}

export async function getStoredUser(): Promise<AuthUser | null> {
  const json = await AsyncStorage.getItem(USER_KEY);
  return json ? JSON.parse(json) : null;
}

export async function getStoredTokens(): Promise<AuthTokens | null> {
  const json = await AsyncStorage.getItem(TOKEN_KEY);
  return json ? JSON.parse(json) : null;
}

export async function requestPasswordReset(email: string): Promise<void> {
  await axios.post(`${API_BASE_URL}/auth/forgot-password`, { email });
}

export async function resetPassword(token: string, newPassword: string): Promise<void> {
  if (newPassword.length < 8) {
    throw new Error('Password must be at least 8 characters');
  }
  await axios.post(`${API_BASE_URL}/auth/reset-password`, { token, newPassword });
}

async function persistSession(user: AuthUser, tokens: AuthTokens): Promise<void> {
  await AsyncStorage.multiSet([
    [TOKEN_KEY, JSON.stringify(tokens)],
    [USER_KEY, JSON.stringify(user)],
  ]);
}
