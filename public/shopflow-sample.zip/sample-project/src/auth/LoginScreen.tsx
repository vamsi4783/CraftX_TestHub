import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert, ActivityIndicator } from 'react-native';
import { login, loginWithGoogle, authenticateWithBiometrics, getStoredUser } from './authService';
import { useDispatch } from 'react-redux';
import { setUser } from './authSlice';

export function LoginScreen({ navigation }: { navigation: any }) {
  const dispatch = useDispatch();
  const [email, setEmail]       = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading]   = useState(false);

  const handleLogin = async () => {
    if (!email.trim() || !password.trim()) {
      Alert.alert('Error', 'Please enter email and password');
      return;
    }
    setLoading(true);
    try {
      const { user } = await login({ email: email.trim(), password });
      dispatch(setUser(user));
      navigation.replace('Main');
    } catch (e: any) {
      Alert.alert('Login Failed', e.message ?? 'Unknown error');
    } finally {
      setLoading(false);
    }
  };

  const handleBiometric = async () => {
    const stored = await getStoredUser();
    if (!stored) {
      Alert.alert('No saved session', 'Log in once before using biometrics');
      return;
    }
    const ok = await authenticateWithBiometrics();
    if (ok) {
      dispatch(setUser(stored));
      navigation.replace('Main');
    } else {
      Alert.alert('Biometric failed', 'Please use email and password instead');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>ShopFlow</Text>
      <TextInput
        style={styles.input}
        placeholder="Email"
        autoCapitalize="none"
        keyboardType="email-address"
        value={email}
        onChangeText={setEmail}
      />
      <TextInput
        style={styles.input}
        placeholder="Password"
        secureTextEntry
        value={password}
        onChangeText={setPassword}
      />
      <TouchableOpacity style={styles.button} onPress={handleLogin} disabled={loading}>
        {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>Log In</Text>}
      </TouchableOpacity>
      <TouchableOpacity onPress={handleBiometric}>
        <Text style={styles.link}>Use Face ID / Fingerprint</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => navigation.navigate('Register')}>
        <Text style={styles.link}>Create account</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => navigation.navigate('ForgotPassword')}>
        <Text style={styles.link}>Forgot password?</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', padding: 24 },
  title: { fontSize: 32, fontWeight: 'bold', marginBottom: 32, textAlign: 'center' },
  input: { borderWidth: 1, borderColor: '#ddd', borderRadius: 8, padding: 12, marginBottom: 12 },
  button: { backgroundColor: '#007AFF', borderRadius: 8, padding: 14, alignItems: 'center', marginBottom: 16 },
  buttonText: { color: '#fff', fontWeight: '600', fontSize: 16 },
  link: { color: '#007AFF', textAlign: 'center', marginTop: 8 },
});
