import { getAnalytics, logEvent } from 'firebase/analytics';
import { getApp } from 'firebase/app';

export type AnalyticsEvent =
  | { name: 'view_product'; params: { product_id: string; product_name: string; category: string } }
  | { name: 'add_to_cart'; params: { product_id: string; price: number; quantity: number } }
  | { name: 'remove_from_cart'; params: { product_id: string } }
  | { name: 'begin_checkout'; params: { value: number; num_items: number } }
  | { name: 'purchase'; params: { transaction_id: string; value: number; items: string[] } }
  | { name: 'search'; params: { search_term: string; results_count: number } }
  | { name: 'login'; params: { method: 'email' | 'google' | 'apple' | 'biometric' } }
  | { name: 'sign_up'; params: { method: 'email' } }
  | { name: 'apply_coupon'; params: { coupon_code: string } };

export function track(event: AnalyticsEvent): void {
  try {
    const analytics = getAnalytics(getApp());
    logEvent(analytics, event.name, event.params);
  } catch {
    // Analytics should never crash the app
  }
}

export function trackScreenView(screenName: string): void {
  try {
    const analytics = getAnalytics(getApp());
    logEvent(analytics, 'screen_view', { screen_name: screenName });
  } catch {}
}
